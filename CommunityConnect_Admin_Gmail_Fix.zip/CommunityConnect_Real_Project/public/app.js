let me=null, adminCurrentTab="users";

const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const fmt=s=>s?new Date(String(s).endsWith("Z")?s:s+"Z").toLocaleString([],{dateStyle:"medium",timeStyle:"short"}):"—";
const statusClass=s=>String(s||"").replace(/\s+/g,"-");

async function api(url, options={}) {
  try {
    const res=await fetch(url,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
    let data={}; try{data=await res.json()}catch{}
    if(!res.ok) throw new Error(data.error||`Request failed (${res.status})`);
    return data;
  } catch(err) {
    if(err instanceof TypeError) throw new Error("Cannot connect to the server. Make sure you started the project with npm start.");
    throw err;
  }
}

function toast(msg,type="info"){
  const t=$("toast"); t.textContent=msg; t.className=`toast show ${type}`;
  clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>t.className="toast",3500);
}

function setLoading(el,text="Loading..."){ if(el) el.innerHTML=`<div class="loading"><span></span>${esc(text)}</div>`; }

async function boot(){
  try{me=(await api("/api/me")).user}catch{me=null}
  updateNav();
  await loadPublic();
  if(me) showDashboard();
}

function updateNav(){
  const b=$("navAuth");
  if(me){
    b.textContent=me.role==="admin"?"Admin Dashboard":"My Dashboard";
    b.onclick=showDashboard;
  }else{
    b.textContent="Sign In";
    b.onclick=()=>openModal("login");
  }
  const resourceAction=$("resourceAction");
  if(resourceAction){
    resourceAction.classList.toggle("hidden",me?.role!=="admin");
    resourceAction.textContent="Manage Resources";
  }
}

async function loadPublic(){
  try{
    const [problems,resources]=await Promise.all([api("/api/problems"),api("/api/resources")]);
    window.publicProblems=problems;
    $("heroProblems").textContent=problems.length;
    $("heroResources").textContent=resources.length;
    $("heroResolved").textContent=problems.filter(x=>x.status==="Resolved").length;

    $("problemCards").innerHTML=problems.length?problems.map(p=>`
      <article class="card problem-card">
        <div class="card-top"><span class="tag">${esc(p.category)}</span><span class="status ${statusClass(p.status)}">${esc(p.status)}</span></div>
        <h3><button class="link-button problem-title" onclick="viewPublicProblem(${p.id})">${esc(p.title)}</button></h3>
        <p>${esc(p.description)}</p>
        ${p.admin_note?`<div class="notice report-update"><strong>Administrator update</strong><p>${esc(p.admin_note)}</p></div>`:""}
        <p class="meta">${p.location?esc(p.location)+" · ":""}Reported by ${esc(p.author)} · ${fmt(p.created_at)}</p>
      </article>`).join(""):`<div class="empty-state"><div class="empty-icon">01</div><h3>No problems reported yet</h3><p>Be the first community member to submit a problem.</p></div>`;

    $("resourceCards").innerHTML=resources.length?resources.map(r=>`
      <article class="card resource-card">
        <span class="tag">${esc(r.category)}</span><h3>${esc(r.title)}</h3>
        <p>${esc(r.description)}</p><p class="meta">Shared by ${esc(r.author)} · ${fmt(r.created_at)}</p>
        ${r.link?`<a class="btn outline" href="${esc(r.link)}" target="_blank" rel="noopener">Open Resource <span>↗</span></a>`:""}
      </article>`).join(""):`<div class="empty-state"><div class="empty-icon">RESOURCE HUB</div><h3>Resource library is ready</h3><p>Community resources added by the administrator will appear here.</p></div>`;
  }catch(err){
    $("problemCards").innerHTML=`<div class="empty-state error-state"><h3>Unable to load community data</h3><p>${esc(err.message)}</p><button class="btn primary" onclick="loadPublic()">Try Again</button></div>`;
    $("resourceCards").innerHTML="";
  }
}

function requireUser(type){
  if(!me){openModal("login");return}
  openModal(type);
}

function openModal(type){
  $("modal").classList.remove("hidden");
  document.body.classList.add("modal-open");
  const form=$("modalForm");
  if(type==="login") renderLogin(form);
  else if(type==="register") renderRegister(form);
  else if(type==="report") renderReport(form);
  else if(type==="adminResource") {
    if(me?.role!=="admin"){closeModal();toast("Only the administrator can manage resources.","error");return;}
    renderAdminResource(form);
  }
}

function closeModal(){
  $("modal").classList.add("hidden");
  document.body.classList.remove("modal-open");
  $("modalForm").innerHTML="";
}

function renderLogin(form){
  $("modalTitle").textContent="Welcome back";
  $("modalSub").textContent="Sign in to access your CommunityConnect dashboard.";
  form.innerHTML=`<div class="field"><label>Email address</label><input id="fEmail" type="email" autocomplete="email" required></div>
  <div class="field"><label>Password</label><input id="fPassword" type="password" autocomplete="current-password" required></div>
  <div id="formError" class="form-error"></div><button class="btn primary full">Sign In</button>
  <div class="switch">New to CommunityConnect? <button type="button" onclick="openModal('register')">Create an account</button></div>
  <div class="demo-note"><strong>Administrator account</strong><br>Use the ADMIN_EMAIL and ADMIN_PASSWORD configured in the project .env file.<br><small>For an untouched demo setup only: admin@communityconnect.local · Admin@123</small></div>`;
  form.onsubmit=async e=>{
    e.preventDefault();
    const btn=form.querySelector("button.btn.primary"); btn.disabled=true; btn.textContent="Signing in...";
    try{
      await api("/api/login",{method:"POST",body:JSON.stringify({email:$("fEmail").value,password:$("fPassword").value})});
      closeModal(); me=(await api("/api/me")).user; updateNav(); showDashboard(); toast("Signed in successfully","success");
    }catch(err){$("formError").textContent=err.message}
    finally{btn.disabled=false;btn.textContent="Sign In"}
  };
}

function renderRegister(form){
  $("modalTitle").textContent="Create your account";
  $("modalSub").textContent="Join the community and start making a difference.";
  form.innerHTML=`<div class="field"><label>Full Name</label><input id="fName" autocomplete="name" required></div>
  <div class="field"><label>Email address</label><input id="fEmail" type="email" autocomplete="email" required></div>
  <div class="field"><label>Password</label><input id="fPassword" type="password" minlength="8" autocomplete="new-password" required><small class="muted">At least 8 characters</small></div>
  <div id="formError" class="form-error"></div><button class="btn primary full">Create Account</button>
  <div class="switch">Already registered? <button type="button" onclick="openModal('login')">Sign in</button></div>`;
  form.onsubmit=async e=>{
    e.preventDefault();
    const btn=form.querySelector("button.btn.primary"); btn.disabled=true; btn.textContent="Creating account...";
    try{
      await api("/api/register",{method:"POST",body:JSON.stringify({name:$("fName").value,email:$("fEmail").value,password:$("fPassword").value})});
      closeModal(); me=(await api("/api/me")).user; updateNav(); showDashboard(); toast("Account created successfully","success");
    }catch(err){$("formError").textContent=err.message}
    finally{btn.disabled=false;btn.textContent="Create Account"}
  };
}

function renderReport(form){
  $("modalTitle").textContent="Report a community problem";
  $("modalSub").textContent="Give enough detail so the administrator can review and act on it.";
  form.innerHTML=`<div class="field"><label>Problem Title</label><input id="pTitle" placeholder="Example: Street lighting near school" required></div>
  <div class="field"><label>Category</label><select id="pCategory"><option>Infrastructure</option><option>Environment</option><option>Public Services</option><option>Safety</option><option>Education</option><option>Other</option></select></div>
  <div class="field"><label>Location</label><input id="pLocation" placeholder="Area or locality"></div>
  <div class="field"><label>Description</label><textarea id="pDescription" placeholder="Explain the problem, impact and any useful details." required></textarea></div>
  <div id="formError" class="form-error"></div><button class="btn primary full">Submit Problem</button>`;
  form.onsubmit=async e=>{
    e.preventDefault();
    try{
      await api("/api/problems",{method:"POST",body:JSON.stringify({title:$("pTitle").value,category:$("pCategory").value,location:$("pLocation").value,description:$("pDescription").value})});
      closeModal(); await loadPublic(); if(me?.role==="admin") await loadAdmin(); toast("Problem reported successfully","success");
    }catch(err){$("formError").textContent=err.message}
  };
}

function renderResource(form, data=null, adminMode=true){
  if(me?.role!=="admin"){
    toast("Only the administrator can manage resources.","error");
    closeModal();
    return;
  }
  const editing=!!data;
  $("modalTitle").textContent=editing?"Edit Resource":"Share a Resource";
  $("modalSub").textContent=editing?"Update the resource information below.":"Help other community members find something useful.";
  form.innerHTML=`<div class="field"><label>Resource Title</label><input id="rTitle" value="${esc(data?.title)}" required></div>
  <div class="field"><label>Category</label><select id="rCategory">${["Local Services","Knowledge","Volunteer","Education","Support","Community Support","Healthcare","Other"].map(x=>`<option ${x===data?.category?"selected":""}>${x}</option>`).join("")}</select></div>
  <div class="field"><label>Description</label><textarea id="rDescription" required>${esc(data?.description)}</textarea></div>
  <div class="field"><label>Website Link <span class="muted">(optional)</span></label><input id="rLink" value="${esc(data?.link)}" placeholder="https://example.com"></div>
  <div id="formError" class="form-error"></div><button class="btn primary full">${editing?"Save Changes":"Share Resource"}</button>`;
  form.onsubmit=async e=>{
    e.preventDefault();
    const payload={title:$("rTitle").value,category:$("rCategory").value,description:$("rDescription").value,link:$("rLink").value};
    try{
      const endpoint = editing ? `/api/admin/resources/${data.id}` : "/api/admin/resources";
      const method = editing ? "PATCH" : "POST";
      await api(endpoint,{method,body:JSON.stringify(payload)});
      closeModal(); await loadPublic(); if(me?.role==="admin") await loadAdmin(); toast(editing?"Resource updated":"Resource added successfully","success");
    }catch(err){$("formError").textContent=err.message}
  };
}

function renderAdminResource(form){ renderResource(form, null, true); }

function showPublicPage(){
  $("dashboardPage").classList.add("hidden");
  $("publicPage").classList.remove("hidden");
}

function showDashboard(){
  $("publicPage").classList.add("hidden");
  $("dashboardPage").classList.remove("hidden");
  $("dashTitle").textContent=me.role==="admin"?"Admin Dashboard":"Member Dashboard";
  $("dashUser").textContent=`Signed in as ${me.name} · ${me.email}`;
  $("adminDash").classList.toggle("hidden",me.role!=="admin");
  $("userDash").classList.toggle("hidden",me.role==="admin");
  if(me.role==="admin") loadAdmin();
  else loadUserDashboard();
  window.scrollTo({top:0,behavior:"smooth"});
}

async function loadUserDashboard(){
  try{
    const [mineProblems,resources]=await Promise.all([api("/api/my/problems"),api("/api/resources")]);
    $("accountInfo").innerHTML=`<strong>${esc(me.name)}</strong><br>${esc(me.email)}<br><span class="muted">Member account</span>`;
    $("myStats").innerHTML=`<div><strong>${mineProblems.length}</strong><span>My Reports</span></div><div><strong>${resources.length}</strong><span>Published Resources</span></div>`;
    let list=$("myReports");
    if(!list){ list=document.createElement("div"); list.id="myReports"; list.className="my-reports"; $("userDash").appendChild(list); }
    list.innerHTML=`<div class="table-header"><div><h2>My Problem Reports</h2><p>Track each report and read the administrator's latest update.</p></div><button class="btn outline" onclick="loadUserDashboard()">Refresh</button></div>
      ${mineProblems.length?mineProblems.map(p=>`<article class="card my-report-card"><div class="card-top"><span class="tag">${esc(p.category)}</span><span class="status ${statusClass(p.status)}">${esc(p.status)}</span></div><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p><p class="meta">${p.location?esc(p.location)+" · ":""}Reported ${fmt(p.created_at)}</p>${p.admin_note?`<div class="notice report-update"><strong>Administrator update</strong><p>${esc(p.admin_note)}</p></div>`:`<p class="muted">No administrator update yet. Check back later.</p>`}</article>`).join(""):`<div class="empty-state"><h3>You have not reported a problem yet</h3><p>Your reports and their progress will appear here.</p></div>`}`;
  }catch(err){$("accountInfo").textContent=err.message}
}

async function logout(){
  try{await api("/api/logout",{method:"POST"})}catch{}
  me=null; updateNav(); $("dashboardPage").classList.add("hidden"); $("publicPage").classList.remove("hidden"); await loadPublic(); toast("You have been logged out");
}

async function loadAdmin(){
  try{
    const s=await api("/api/admin/overview");
    $("adminStats").innerHTML=[
      ["users","Registered Users",s.users,"01"],
      ["problems","Reported Problems",s.problems,"02"],
      ["resolved","Resolved Problems",s.resolved,"03"],
      ["resources","Resources",s.resources,"04"]
    ].map(x=>`<div class="admin-stat"><div class="stat-icon">${x[3]}</div><div><strong>${x[2]}</strong><span>${x[1]}</span></div></div>`).join("");
    const active=document.querySelector(".tab.active")?.dataset.tab||adminCurrentTab;
    adminTab(active,document.querySelector(`.tab[data-tab="${active}"]`));
  }catch(err){$("adminTable").innerHTML=`<div class="empty-state error-state"><h3>Dashboard data could not be loaded</h3><p>${esc(err.message)}</p><button class="btn primary" onclick="loadAdmin()">Try Again</button></div>`}
}

async function adminTab(tab,button){
  adminCurrentTab=tab;
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
  if(button)button.classList.add("active");
  const box=$("adminTable"); setLoading(box);
  try{
    if(tab==="users"){
      const rows=await api("/api/admin/users");
      box.innerHTML=`<div class="table-header"><div><h3>User Accounts</h3><p>All registered community members and administrator accounts.</p></div></div>
      <div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Registered</th><th>Last Login</th></tr></thead><tbody>${rows.map(r=>`<tr><td><strong>${esc(r.name)}</strong></td><td>${esc(r.email)}</td><td><span class="role ${r.role}">${esc(r.role)}</span></td><td>${fmt(r.created_at)}</td><td>${fmt(r.last_login)}</td></tr>`).join("")}</tbody></table></div>`;
    }else if(tab==="logins"){
      const rows=await api("/api/admin/logins");
      box.innerHTML=`<div class="table-header"><div><h3>Login Activity</h3><p>Recent sign-in activity from registered accounts.</p></div></div>
      <div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Email</th><th>Role</th><th>Login Time</th><th>IP Address</th></tr></thead><tbody>${rows.length?rows.map(r=>`<tr><td><strong>${esc(r.name)}</strong></td><td>${esc(r.email)}</td><td><span class="role ${r.role}">${esc(r.role)}</span></td><td>${fmt(r.logged_in_at)}</td><td>${esc(r.ip_address||"—")}</td></tr>`).join(""):`<tr><td colspan="5" class="empty-cell">No login activity yet.</td></tr>`}</tbody></table></div>`;
    }else if(tab==="problems"){
      const rows=await api("/api/admin/problems");
      window.adminProblems=rows;
      box.innerHTML=`<div class="table-header"><div><h3>Problem Management</h3><p>Open a report to review the full description, then update its status.</p></div><span class="count-badge">${rows.length} total</span></div>
      <div class="table-wrap"><table class="table"><thead><tr><th>Problem</th><th>Reporter</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead><tbody>${rows.length?rows.map(r=>`<tr>
        <td><button class="link-button" onclick='viewProblem(${r.id})'><strong>${esc(r.title)}</strong></button><br><span class="meta">${esc(r.category)}${r.location?" · "+esc(r.location):""}</span></td>
        <td>${esc(r.author)}<br><span class="meta">${esc(r.author_email)}</span></td>
        <td><select class="status-select ${statusClass(r.status)}" onchange="changeStatus(${r.id},this.value)">${["Open","In Progress","Resolved","Rejected"].map(s=>`<option ${s===r.status?"selected":""}>${s}</option>`).join("")}</select></td>
        <td>${fmt(r.created_at)}</td>
        <td><button class="icon-action danger" onclick="deleteProblem(${r.id})">Delete</button></td>
      </tr>`).join(""):`<tr><td colspan="5" class="empty-cell">No problems have been reported.</td></tr>`}</tbody></table></div>`;
    }else{
      const rows=await api("/api/admin/resources");
      window.adminResources=rows;
      box.innerHTML=`<div class="table-header"><div><h3>Resource Management</h3><p>Add, edit and remove resources shown in the public Resource Hub.</p></div><button class="btn primary" onclick="openModal('adminResource')">+ Add Resource</button></div>
      <div class="table-wrap"><table class="table"><thead><tr><th>Resource</th><th>Category</th><th>Added By</th><th>Created</th><th>Actions</th></tr></thead><tbody>${rows.length?rows.map(r=>`<tr>
        <td><strong>${esc(r.title)}</strong><br><span class="meta">${esc(r.description).slice(0,90)}${r.description.length>90?"…":""}</span></td>
        <td><span class="tag">${esc(r.category)}</span></td><td>${esc(r.author)}</td><td>${fmt(r.created_at)}</td>
        <td class="actions-cell"><button class="icon-action" onclick='editResource(${r.id})'>Edit</button><button class="icon-action danger" onclick="deleteResource(${r.id})">Delete</button></td>
      </tr>`).join(""):`<tr><td colspan="5" class="empty-cell">No resources yet. Click “Add Resource” to create one.</td></tr>`}</tbody></table></div>`;
    }
  }catch(err){
    box.innerHTML=`<div class="empty-state error-state"><h3>Could not load this section</h3><p>${esc(err.message)}</p><button class="btn primary" onclick="adminTab('${tab}',document.querySelector('.tab.active'))">Try Again</button></div>`;
  }
}

function viewPublicProblem(id){
  const r=(window.publicProblems||[]).find(x=>Number(x.id)===Number(id));
  if(!r)return;
  const isAdmin=me?.role==="admin";
  $("modal").classList.remove("hidden"); document.body.classList.add("modal-open");
  $("modalTitle").textContent="Community Problem Report";
  $("modalSub").textContent=`Reported by ${r.author} · ${fmt(r.created_at)}`;
  $("modalForm").innerHTML=`<div class="detail-grid"><div><span class="detail-label">Category</span><strong>${esc(r.category)}</strong></div><div><span class="detail-label">Current Status</span><span class="status ${statusClass(r.status)}">${esc(r.status)}</span></div></div>
  <div class="detail-block"><span class="detail-label">Title</span><h3>${esc(r.title)}</h3></div>
  <div class="detail-block"><span class="detail-label">Location</span><p>${esc(r.location||"Not provided")}</p></div>
  <div class="detail-block"><span class="detail-label">Description</span><p class="detail-description">${esc(r.description)}</p></div>
  ${r.admin_note?`<div class="detail-block admin-response"><span class="detail-label">Administrator update</span><p>${esc(r.admin_note)}</p></div>`:""}
  ${isAdmin?`<div class="field"><label>Update status</label><select id="publicProblemStatus">${["Open","In Progress","Resolved","Rejected"].map(s=>`<option ${s===r.status?"selected":""}>${s}</option>`).join("")}</select></div><div class="field"><label>Action taken / message to reporter</label><textarea id="publicProblemNote" maxlength="2000" placeholder="Explain what action was taken, who was contacted, or what the reporter should do next.">${esc(r.admin_note||"")}</textarea><small class="muted">This update is visible on the public problem report.</small></div><button type="button" class="btn primary full" onclick="savePublicProblemStatus(${r.id})">Save Update</button>`:""}
  <button type="button" class="btn outline full modal-secondary" onclick="closeModal()">Close</button>`;
}

async function savePublicProblemStatus(id){
  try{
    const status = $("publicProblemStatus").value;
    const admin_note = $("publicProblemNote").value;
    const result = await api(`/api/admin/problems/${id}`,{method:"PATCH",body:JSON.stringify({status,admin_note})});
    closeModal(); await loadPublic(); if(me?.role==="admin") await loadAdmin();
    toast(result.message || "Problem update saved","success");
  }catch(err){toast(err.message,"error")}
}

function viewProblem(id){
  const r=(window.adminProblems||[]).find(x=>Number(x.id)===Number(id));
  if(!r)return;
  viewPublicProblem(id);
  $("modalSub").textContent=`Submitted by ${r.author} · ${r.author_email} · ${fmt(r.created_at)}`;
}


function editResource(id){
  const r=(window.adminResources||[]).find(x=>Number(x.id)===Number(id));
  if(!r)return;
  openModal("adminResource"); renderResource($("modalForm"),r,true);
}

async function changeStatus(id,status){
  try{const r=(window.adminProblems||[]).find(p=>Number(p.id)===Number(id));const result=await api("/api/admin/problems/"+id,{method:"PATCH",body:JSON.stringify({status,admin_note:r?.admin_note||""})});toast(result.message || "Problem status updated","success");await loadAdmin();await loadPublic()}
  catch(e){toast(e.message,"error")}
}

async function deleteProblem(id){
  if(!confirm("Delete this problem permanently?"))return;
  try{await api("/api/admin/problems/"+id,{method:"DELETE"});toast("Problem deleted","success");await loadAdmin();await loadPublic()}
  catch(e){toast(e.message,"error")}
}

async function deleteResource(id){
  if(!confirm("Delete this resource permanently?"))return;
  try{await api("/api/admin/resources/"+id,{method:"DELETE"});toast("Resource deleted","success");await loadAdmin();await loadPublic()}
  catch(e){toast(e.message,"error")}
}

$("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&!$("modal").classList.contains("hidden"))closeModal()});
boot();
