# CommunityConnect — Real Full-Stack Project

This is a real local full-stack application using:

- Node.js
- Express
- SQLite
- better-sqlite3
- bcrypt password hashing
- HTTP-only session cookie authentication
- Admin role access control
- Real database persistence
- Real problem reporting
- Administrator-managed resource library with starter resources
- Login activity tracking
- Admin problem status management

## 1. Install Node.js

Install the current LTS version of Node.js from the official Node.js website.

Then restart VS Code.

## 2. Open this folder in VS Code

Open the folder:

CommunityConnect_Real_Project

The important files are:

server.js
package.json
public/index.html
public/style.css
public/app.js

## 3. Open the VS Code terminal

Use:

Terminal > New Terminal

Then run:

npm install

Wait until installation finishes.

## 4. Start the project

Run:

npm start

You should see:

CommunityConnect running at http://localhost:3000

Open:

http://localhost:3000

Do NOT open public/index.html directly. The website must run through the Node.js server.

## 5. Administrator account

Email:
admin@communityconnect.local

Password:
Admin@123

After login, the administrator can see:

- Registered users
- Last login time
- Login activity
- Problems submitted by users
- Reporter information
- Problem status
- Open and review full problem reports
- Delete problem
- Add, edit and delete resources from the admin dashboard
- Review and update any problem report, including reports created while signed in as the administrator
- Platform statistics

## 6. Test the real user flow

1. Open http://localhost:3000
2. Click Sign In
3. Create a normal account.
4. Report a problem.
5. Open the Resource Hub to view administrator-published resources. Only the administrator can add, edit, or delete resources.
6. Log out.
7. Log in again.
8. Open the admin account in another browser/incognito window.
9. Open Admin Dashboard.
10. You will see the user and login activity.

## Database

The SQLite database is automatically created at:

database/community.db

It stores:

- users
- sessions
- login_logs
- problems
- resources

You do not need to manually create the database.

## Important security note

This is a proper local full-stack project for learning and college/project demonstration. Before public production deployment, add HTTPS, secure production secrets, stronger validation/rate limiting, email verification/password reset, database backups, and a production session strategy.

The demo admin credentials should also be changed before deployment. Starter resources are inserted automatically only when the resources table is empty. For local testing, sign in with the administrator account above to open the Admin Dashboard. If you are signed in with a normal member account, log out and sign in as the administrator to manage all reports and resources.


## Email notifications for report updates

The application sends an email to the person who submitted a report whenever an administrator changes its status or administrator message. It also displays the report's current status and the administrator message in the user's **My Dashboard → My Problem Reports** section.

To enable email notifications:
1. Run `npm install` in the folder containing `package.json`.
2. Copy `.env.example` to a new file named `.env`.
3. For Gmail, enable 2-Step Verification in your Google account and create an **App Password**. Use that App Password in `SMTP_PASS`; do not use your regular Gmail password.
4. Put your Gmail address in `SMTP_USER` and `MAIL_FROM`. Keep `.env` private and never upload it to GitHub.
5. Restart the server using `npm start`.

If SMTP settings are not configured, status updates will still save and appear on the website, but no email will be sent. The admin interface will show that email configuration is missing.

Demo admin credentials are `admin@communityconnect.local` / `Admin@123`. Change the demo credentials before deploying publicly.

## Configure your own administrator Gmail

1. Copy `.env.example` to a new file named `.env` in the same folder as `server.js`.
2. Set `ADMIN_EMAIL` to your own Gmail address (lowercase is fine).
3. Set `ADMIN_PASSWORD` to a strong password for signing in to this website. This is not your Gmail password.
4. Save the file and restart the server with `npm start`. On startup, that email is assigned the administrator role and the website password is set to `ADMIN_PASSWORD`.
5. Sign out and sign in again using that email and website password. Back up `database/community.db` before changing configuration.

If `.env` is not configured, the local demo administrator remains `admin@communityconnect.local` with password `Admin@123`. Change these demo credentials before public deployment.
