const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const { v4: uuidv4 } = require("uuid");
require("dotenv").config();
const nodemailer = require("nodemailer");

const app = express();
const PORT = process.env.PORT || 3000;

function createMailTransport() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || "false").toLowerCase() === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

async function emailProblemUpdate({ to, name, title, status, note, problemId }) {
  const transport = createMailTransport();
  if (!transport) return "not_configured";
  const from = process.env.MAIL_FROM || process.env.SMTP_USER;
  const baseUrl = process.env.APP_URL || `http://localhost:${PORT}`;
  const message = note || "The status of your reported problem has been updated.";
  await transport.sendMail({
    from,
    to,
    subject: `CommunityConnect update: ${title} — ${status}`,
    text: `Hello ${name},

There is an update to your CommunityConnect problem report.

Problem: ${title}
Status: ${status}
Administrator update: ${message}

Sign in to CommunityConnect to view your report: ${baseUrl}

Thank you,
CommunityConnect`,
    html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#1f2937"><h2>CommunityConnect report update</h2><p>Hello ${escapeHtml(name)},</p><p>Your reported problem has been updated.</p><div style="padding:16px;background:#f3f6fb;border-radius:8px"><p><b>Problem:</b> ${escapeHtml(title)}</p><p><b>Status:</b> ${escapeHtml(status)}</p><p><b>Administrator update:</b><br>${escapeHtml(message).replace(/\n/g,"<br>")}</p></div><p><a href="${escapeHtml(baseUrl)}">Sign in to view your report</a></p><p>Thank you,<br>CommunityConnect</p></div>`
  });
  return "sent";
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}

const databaseDir = path.join(__dirname, "database");
require("fs").mkdirSync(databaseDir, { recursive: true });
const db = new Database(path.join(databaseDir, "community.db"));

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS login_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  logged_in_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ip_address TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS problems (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'Open' CHECK(status IN ('Open','In Progress','Resolved','Rejected')),
  admin_note TEXT NOT NULL DEFAULT '',
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS resources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  link TEXT,
  created_by INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE
);
`);

// Keep a predictable local demo administrator available even if this project
// is copied over a database that already contains the same email as a normal user.
// Change these demo credentials before deploying the application publicly.
const adminEmail = (process.env.ADMIN_EMAIL || "admin@communityconnect.local").trim().toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || "Admin@123";
const adminHash = bcrypt.hashSync(adminPassword, 12);
db.prepare(`
  INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')
  ON CONFLICT(email) DO UPDATE SET
    name=excluded.name,
    password_hash=excluded.password_hash,
    role='admin'
`).run("System Administrator", adminEmail, adminHash);

// Safe schema migration for projects whose SQLite database was created earlier.
const problemColumns = db.prepare("PRAGMA table_info(problems)").all().map(column => column.name);
if (!problemColumns.includes("admin_note")) {
  db.exec("ALTER TABLE problems ADD COLUMN admin_note TEXT NOT NULL DEFAULT ''");
}

// Seed useful starter resources once so the Resource Hub is not empty on first launch.
if (db.prepare("SELECT COUNT(*) AS count FROM resources").get().count === 0) {
  const admin = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
  const seedResource = db.prepare(`
    INSERT INTO resources (title,description,category,link,created_by)
    VALUES (?,?,?,?,?)
  `);
  [
    ["National Portal of India", "A central starting point for information about government services, departments and public programmes.", "Local Services", "https://www.india.gov.in/"],
    ["National Scholarship Portal", "Explore scholarship schemes and official scholarship application information for eligible students.", "Education", "https://scholarships.gov.in/"],
    ["MyGov India", "Discover public consultations, citizen participation activities and opportunities to contribute ideas.", "Community Support", "https://www.mygov.in/"],
    ["National Health Portal", "Find general health information and public health resources from India's health information portal.", "Healthcare", "https://www.nhp.gov.in/"]
  ].forEach(([title, description, category, link]) => seedResource.run(title, description, category, link, admin.id));
}

function clean(value, max = 2000) {
  return String(value ?? "").trim().slice(0, max);
}

function currentUser(req) {
  const token = req.cookies.cc_session;
  if (!token) return null;
  const session = db.prepare(`
    SELECT s.token, s.expires_at, u.id, u.name, u.email, u.role
    FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token=?
  `).get(token);
  if (!session) return null;
  if (new Date(session.expires_at) <= new Date()) {
    db.prepare("DELETE FROM sessions WHERE token=?").run(token);
    return null;
  }
  return { id: session.id, name: session.name, email: session.email, role: session.role, token };
}

function requireAuth(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: "Please sign in first." });
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  const user = currentUser(req);
  if (!user || user.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  req.user = user;
  next();
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/register", (req, res) => {
  const name = clean(req.body.name, 100);
  const email = clean(req.body.email, 150).toLowerCase();
  const password = String(req.body.password || "");

  if (name.length < 2) return res.status(400).json({ error: "Please enter your full name." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Please enter a valid email." });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });

  if (db.prepare("SELECT id FROM users WHERE email=?").get(email))
    return res.status(409).json({ error: "An account with this email already exists." });

  const hash = bcrypt.hashSync(password, 12);
  const result = db.prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)")
    .run(name, email, hash, "user");

  createSession(res, result.lastInsertRowid);
  res.json({ message: "Account created successfully." });
});

app.post("/api/login", (req, res) => {
  const email = clean(req.body.email, 150).toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);

  if (!user || !bcrypt.compareSync(password, user.password_hash))
    return res.status(401).json({ error: "Incorrect email or password." });

  db.prepare("INSERT INTO login_logs (user_id,ip_address) VALUES (?,?)")
    .run(user.id, req.ip);

  createSession(res, user.id);
  res.json({ message: "Signed in successfully.", role: user.role });
});

function createSession(res, userId) {
  const token = uuidv4() + "-" + uuidv4();
  const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
  db.prepare("INSERT INTO sessions (token,user_id,expires_at) VALUES (?,?,?)")
    .run(token, userId, expires);
  res.cookie("cc_session", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  });
}

app.post("/api/logout", (req, res) => {
  const token = req.cookies.cc_session;
  if (token) db.prepare("DELETE FROM sessions WHERE token=?").run(token);
  res.clearCookie("cc_session");
  res.json({ message: "Logged out." });
});

app.get("/api/me", (req, res) => {
  const user = currentUser(req);
  res.json({ user: user ? { id:user.id, name:user.name, email:user.email, role:user.role } : null });
});

app.get("/api/problems", (req, res) => {
  const rows = db.prepare(`
    SELECT p.id,p.title,p.description,p.category,p.location,p.status,p.admin_note,p.created_at,
           u.name AS author
    FROM problems p JOIN users u ON u.id=p.created_by
    ORDER BY p.created_at DESC
  `).all();
  res.json(rows);
});

app.get("/api/my/problems", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT id,title,description,category,location,status,admin_note,created_at
    FROM problems WHERE created_by=? ORDER BY created_at DESC
  `).all(req.user.id);
  res.json(rows);
});

app.post("/api/problems", requireAuth, (req, res) => {
  const title = clean(req.body.title, 150);
  const description = clean(req.body.description, 3000);
  const category = clean(req.body.category, 80);
  const location = clean(req.body.location, 200);

  if (title.length < 5 || description.length < 15 || !category)
    return res.status(400).json({ error: "Please complete all required problem fields." });

  const result = db.prepare(`
    INSERT INTO problems (title,description,category,location,created_by)
    VALUES (?,?,?,?,?)
  `).run(title, description, category, location, req.user.id);

  res.status(201).json({ id: result.lastInsertRowid, message: "Problem reported successfully." });
});

app.get("/api/resources", (req, res) => {
  const rows = db.prepare(`
    SELECT r.id,r.title,r.description,r.category,r.link,r.created_at,u.name AS author
    FROM resources r JOIN users u ON u.id=r.created_by
    ORDER BY r.created_at DESC
  `).all();
  res.json(rows);
});

app.post("/api/resources", (req, res) => {
  res.status(403).json({ error: "Only the administrator can add or manage community resources." });
});

app.get("/api/admin/overview", requireAdmin, (req, res) => {
  const users = db.prepare("SELECT COUNT(*) AS count FROM users WHERE role='user'").get().count;
  const problems = db.prepare("SELECT COUNT(*) AS count FROM problems").get().count;
  const resolved = db.prepare("SELECT COUNT(*) AS count FROM problems WHERE status='Resolved'").get().count;
  const resources = db.prepare("SELECT COUNT(*) AS count FROM resources").get().count;
  res.json({ users, problems, resolved, resources });
});

app.get("/api/admin/users", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT u.id,u.name,u.email,u.role,u.created_at,
      (SELECT MAX(logged_in_at) FROM login_logs l WHERE l.user_id=u.id) AS last_login
    FROM users u ORDER BY u.created_at DESC
  `).all();
  res.json(rows);
});

app.get("/api/admin/logins", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT l.id,u.name,u.email,u.role,l.logged_in_at,l.ip_address
    FROM login_logs l JOIN users u ON u.id=l.user_id
    ORDER BY l.logged_in_at DESC LIMIT 100
  `).all();
  res.json(rows);
});

app.get("/api/admin/problems", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT p.*,u.name AS author,u.email AS author_email
    FROM problems p JOIN users u ON u.id=p.created_by
    ORDER BY p.created_at DESC
  `).all();
  res.json(rows);
});

app.patch("/api/admin/problems/:id", requireAdmin, async (req, res) => {
  const status = clean(req.body.status, 30);
  const adminNote = clean(req.body.admin_note, 2000);
  if (!["Open","In Progress","Resolved","Rejected"].includes(status))
    return res.status(400).json({ error: "Invalid status." });

  const problem = db.prepare(`SELECT p.id,p.title,p.status,p.admin_note,u.name,u.email
    FROM problems p JOIN users u ON u.id=p.created_by WHERE p.id=?`).get(req.params.id);
  if (!problem) return res.status(404).json({ error: "Problem not found." });

  db.prepare("UPDATE problems SET status=?, admin_note=? WHERE id=?")
    .run(status, adminNote, req.params.id);

  let emailStatus = "not_configured";
  // Notify only when the status or administrator message actually changes.
  if (status !== problem.status || adminNote !== problem.admin_note) {
    try {
      emailStatus = await emailProblemUpdate({
        to: problem.email, name: problem.name, title: problem.title,
        status, note: adminNote, problemId: problem.id
      });
    } catch (error) {
      console.error("Problem update email failed:", error.message);
      emailStatus = "failed";
    }
  } else {
    emailStatus = "unchanged";
  }

  const emailMessage = emailStatus === "sent" ? "Email notification sent to the reporter."
    : emailStatus === "not_configured" ? "Saved, but email is not configured yet. Add SMTP settings to .env to send notifications."
    : emailStatus === "failed" ? "Saved, but the email could not be sent. Check SMTP settings and server logs."
    : "No changes detected; no email was sent.";
  res.json({ message: `Problem update saved. ${emailMessage}`, emailStatus });
});

app.get("/api/admin/resources", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT r.*, u.name AS author, u.email AS author_email
    FROM resources r JOIN users u ON u.id=r.created_by
    ORDER BY r.created_at DESC
  `).all();
  res.json(rows);
});

app.post("/api/admin/resources", requireAdmin, (req, res) => {
  const title = clean(req.body.title, 150);
  const description = clean(req.body.description, 3000);
  const category = clean(req.body.category, 80);
  const link = clean(req.body.link, 500);

  if (title.length < 3 || description.length < 10 || !category)
    return res.status(400).json({ error: "Please complete all required resource fields." });

  if (link && !/^https?:\/\//i.test(link))
    return res.status(400).json({ error: "Resource link must start with http:// or https://." });

  const result = db.prepare(`
    INSERT INTO resources (title,description,category,link,created_by)
    VALUES (?,?,?,?,?)
  `).run(title, description, category, link || null, req.user.id);

  res.status(201).json({ id: result.lastInsertRowid, message: "Resource added successfully." });
});

app.patch("/api/admin/resources/:id", requireAdmin, (req, res) => {
  const title = clean(req.body.title, 150);
  const description = clean(req.body.description, 3000);
  const category = clean(req.body.category, 80);
  const link = clean(req.body.link, 500);

  if (title.length < 3 || description.length < 10 || !category)
    return res.status(400).json({ error: "Please complete all required resource fields." });
  if (link && !/^https?:\/\//i.test(link))
    return res.status(400).json({ error: "Resource link must start with http:// or https://." });

  const result = db.prepare(`
    UPDATE resources SET title=?, description=?, category=?, link=? WHERE id=?
  `).run(title, description, category, link || null, req.params.id);

  if (!result.changes) return res.status(404).json({ error: "Resource not found." });
  res.json({ message: "Resource updated successfully." });
});

app.delete("/api/admin/resources/:id", requireAdmin, (req, res) => {
  const result = db.prepare("DELETE FROM resources WHERE id=?").run(req.params.id);
  if (!result.changes) return res.status(404).json({ error: "Resource not found." });
  res.json({ message: "Resource deleted." });
});

app.delete("/api/admin/problems/:id", requireAdmin, (req, res) => {
  const result = db.prepare("DELETE FROM problems WHERE id=?").run(req.params.id);
  if (!result.changes) return res.status(404).json({ error: "Problem not found." });
  res.json({ message: "Problem deleted." });
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => {
  console.log(`CommunityConnect running at http://localhost:${PORT}`);
});
